# Workspaces

Pour réaliser les travaux pratiques, créez ici le(s) application(s) Angular.

Pour sauvegarder votre travail, vous pouvez :

- dès à présent, créer un dépôt sur votre compte Github et le synchroniser au fil des exercices
  (nécessite la connaissance de Git et Github).

- à la fin de la formation, créer une archive de votre travail et l'importer dans le dossier Google Drive partagé par le formateur.

Dans ce cas, pensez à :
  - supprimer le dossier `node_modules` volumineux avant de créer l'archive.
  - renommer l'archive à votre nom pour la retrouver facilement parmi celles des autres stagiaires.

Happy coding :)
