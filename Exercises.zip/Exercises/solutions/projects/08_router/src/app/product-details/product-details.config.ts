export const PRODUCT_DETAILS_PARAM_KEY = 'id';
