import { Component } from '@angular/core';

@Component({
  selector: 'app-basket-empty',
  templateUrl: './basket-empty.component.html',
})
export class BasketEmptyComponent {}
