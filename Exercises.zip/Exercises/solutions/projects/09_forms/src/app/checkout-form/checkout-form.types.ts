export interface CheckoutDetails {
  name: string;
  address: string;
  creditCard: string;
}
