export const config = {
  context: '/api',
  port: 8080,
};
