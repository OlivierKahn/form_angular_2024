Placer les ressources externes ici (applicatifs, ...)

